/**
 * 公司：拓薪教育
 * 文件名：UserController
 * 作者：rlsl180506
 * 时间：2018/9/18 20:35
 * 描述：
 */


package cn.tx.controller;

import cn.tx.model.User;
import cn.tx.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("insert")
    public String insert(User user){
        userService.insert(user);
        return "success";
    }

    @RequestMapping("delete")
    public String delete(int pid){
        userService.delete(pid);
        return "success";
    }

    @RequestMapping("getUser")
    public User getUser(){
        return userService.getUser(1);
    }

    @RequestMapping("listUser")
    public List<User> listUser(){
        return userService.listUser();
    }
}
