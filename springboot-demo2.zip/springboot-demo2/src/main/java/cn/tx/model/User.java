/**
 * 公司：拓薪教育
 * 文件名：User
 * 作者：rlsl180506
 * 时间：2018/9/18 20:11
 * 描述：
 */


package cn.tx.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Setter
@Getter
public class User {


    private int pid;

    private String username;

    private String password;

    private String pAddr;

    private int gender;

    private Date birth;

}
