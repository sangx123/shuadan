/**
 * 公司：拓薪教育
 * 文件名：UserService
 * 作者：rlsl180506
 * 时间：2018/9/18 20:33
 * 描述：
 */


package cn.tx.service;

import cn.tx.model.User;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface UserService {
    public void insert(User user);

    public User getUser(int pid);

    public List<User> listUser();

    public void delete(int pid);



}
