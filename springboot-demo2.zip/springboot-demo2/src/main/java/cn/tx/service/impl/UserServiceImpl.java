/**
 * 公司：拓薪教育
 * 文件名：UserServiceImpl
 * 作者：rlsl180506
 * 时间：2018/9/18 20:33
 * 描述：
 */


package cn.tx.service.impl;

import cn.tx.mapper.UserMapper;
import cn.tx.model.User;
import cn.tx.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;
    @Override
    public void insert(User user) {
        userMapper.insert(user);
    }

    @Override
    public User getUser(int pid) {
        return userMapper.getUser(pid);
    }

    @Override
    public List<User> listUser() {
        return userMapper.listUser();
    }

    @Override
    public void delete(int pid) {
        userMapper.delete(pid);
    }
}
