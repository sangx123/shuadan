/**
 * 公司：拓薪教育
 * 文件名：DataSourceConfig
 * 作者：rlsl180506
 * 时间：2018/9/18 20:24
 * 描述：
 */


package cn.tx.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {


    @ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    public DataSource getCustomDataSource(){
        return new DruidDataSource();
    }

}
